// ============================================================
// Pocket Court — Frontend TypeScript Logic
// ============================================================

interface SearchResult {
  topic_id: string;
  category: string;
  title: string;
  summary: string;
  steps: string[];
  references: string[];
  relevance_score: number;
}

interface CountryInfo {
  code: string;
  name: string;
}

interface ApiResponse<T> {
  success: boolean;
  data: T;
  count: number;
}

// ---- Offline Data (bundled for offline mode) ----
// In production, these would be loaded from local JSON files via a service worker.
// For simplicity, they are imported as static modules or fetched from /data/*.json.

const API_BASE = "http://127.0.0.1:8080";

class PocketCourt {
  private mode: "offline" | "online" = "offline";
  private selectedCountry: string = "";
  private offlineData: Map<string, any> = new Map();

  private elements = {
    modeToggle: document.getElementById("mode-toggle") as HTMLInputElement,
    modeLabel: document.getElementById("mode-label") as HTMLSpanElement,
    countrySelect: document.getElementById("country-select") as HTMLSelectElement,
    situationInput: document.getElementById("situation-input") as HTMLTextAreaElement,
    searchBtn: document.getElementById("search-btn") as HTMLButtonElement,
    resultsSection: document.getElementById("results-section") as HTMLElement,
    resultsContainer: document.getElementById("results-container") as HTMLElement,
    statusBar: document.getElementById("status-bar") as HTMLElement,
    resultCount: document.getElementById("result-count") as HTMLElement,
  };

  constructor() {
    this.initEventListeners();
    this.loadOfflineData();
  }

  private initEventListeners(): void {
    this.elements.modeToggle.addEventListener("change", () => this.onModeToggle());
    this.elements.searchBtn.addEventListener("click", () => this.onSearch());
    this.elements.situationInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) this.onSearch();
    });
    this.elements.countrySelect.addEventListener("change", () => {
      this.selectedCountry = this.elements.countrySelect.value;
    });
  }

  private async loadOfflineData(): Promise<void> {
    const countryCodes = ["us", "gb", "in"];
    const countryNames: Record<string, string> = {
      us: "United States",
      gb: "United Kingdom",
      in: "India",
    };

    this.setStatus("Loading offline law database...", "info");

    for (const code of countryCodes) {
      try {
        const res = await fetch(`../data/${code}.json`);
        if (res.ok) {
          const data = await res.json();
          this.offlineData.set(code.toUpperCase(), data);
        }
      } catch {
        console.warn(`Could not load offline data for ${code}`);
      }
    }

    // Populate country select with offline data
    this.populateCountryDropdown(
      Array.from(this.offlineData.entries()).map(([code, d]) => ({
        code,
        name: d.country_name || countryNames[code.toLowerCase()] || code,
      }))
    );

    this.setStatus("Offline database ready. Enter a situation to begin.", "success");
  }

  private populateCountryDropdown(countries: CountryInfo[]): void {
    this.elements.countrySelect.innerHTML = `<option value="">— Select a Country —</option>`;
    countries
      .sort((a, b) => a.name.localeCompare(b.name))
      .forEach((c) => {
        const opt = document.createElement("option");
        opt.value = c.code;
        opt.textContent = c.name;
        this.elements.countrySelect.appendChild(opt);
      });
  }

  private onModeToggle(): void {
    this.mode = this.elements.modeToggle.checked ? "online" : "offline";
    this.elements.modeLabel.textContent = this.mode === "online" ? "Online" : "Offline";
    this.elements.modeLabel.dataset.mode = this.mode;

    if (this.mode === "online") {
      this.setStatus("Online mode: attempting to connect to backend API...", "info");
      this.tryLoadOnlineCountries();
    } else {
      this.setStatus("Offline mode active. Using local law database.", "success");
      // Re-populate from offline cache
      this.populateCountryDropdown(
        Array.from(this.offlineData.entries()).map(([code, d]) => ({
          code,
          name: d.country_name || code,
        }))
      );
    }
  }

  private async tryLoadOnlineCountries(): Promise<void> {
    try {
      const res = await fetch(`${API_BASE}/api/countries`, { signal: AbortSignal.timeout(3000) });
      if (!res.ok) throw new Error("API unavailable");
      const json: ApiResponse<CountryInfo[]> = await res.json();
      this.populateCountryDropdown(json.data);
      this.setStatus(`Online mode: ${json.count} countries available via API.`, "success");
    } catch {
      this.setStatus("Online mode: Backend API unavailable. Falling back to offline data.", "warning");
      this.mode = "offline";
      this.elements.modeToggle.checked = false;
      this.elements.modeLabel.textContent = "Offline";
      this.elements.modeLabel.dataset.mode = "offline";
    }
  }

  private async onSearch(): Promise<void> {
    const country = this.elements.countrySelect.value;
    const situation = this.elements.situationInput.value.trim();

    if (!country) {
      this.setStatus("Please select a country.", "warning");
      this.elements.countrySelect.focus();
      return;
    }
    if (!situation || situation.length < 5) {
      this.setStatus("Please describe your situation (at least 5 characters).", "warning");
      this.elements.situationInput.focus();
      return;
    }

    this.elements.searchBtn.disabled = true;
    this.elements.searchBtn.textContent = "Searching...";
    this.setStatus("Analyzing your situation...", "info");

    try {
      const results =
        this.mode === "online"
          ? await this.searchOnline(country, situation)
          : this.searchOffline(country, situation);

      this.displayResults(results);
    } catch (err) {
      this.setStatus(`Error: ${(err as Error).message}`, "error");
      this.elements.resultsSection.classList.add("hidden");
    } finally {
      this.elements.searchBtn.disabled = false;
      this.elements.searchBtn.textContent = "Find Legal Guidance";
    }
  }

  private async searchOnline(country: string, situation: string): Promise<SearchResult[]> {
    const res = await fetch(`${API_BASE}/api/search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ country_code: country, situation }),
      signal: AbortSignal.timeout(5000),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || "Search failed");
    }

    const json: ApiResponse<SearchResult[]> = await res.json();
    return json.data;
  }

  private searchOffline(country: string, situation: string): SearchResult[] {
    const lawData = this.offlineData.get(country.toUpperCase());
    if (!lawData) throw new Error(`No offline data available for country: ${country}`);

    const queryWords = tokenize(situation);
    if (queryWords.length === 0) throw new Error("Please enter a more descriptive situation.");

    const results: SearchResult[] = lawData.topics
      .map((topic: any) => {
        const score = computeRelevance(queryWords, topic);
        return score > 0
          ? {
              topic_id: topic.id,
              category: topic.category,
              title: topic.title,
              summary: topic.summary,
              steps: topic.steps,
              references: topic.references,
              relevance_score: score,
            }
          : null;
      })
      .filter(Boolean) as SearchResult[];

    results.sort((a, b) => b.relevance_score - a.relevance_score);

    if (results.length === 0) {
      throw new Error(
        "No matching legal topics found. Try different keywords (e.g., 'eviction', 'fired', 'debt', 'arrested')."
      );
    }

    return results;
  }

  private displayResults(results: SearchResult[]): void {
    this.elements.resultsContainer.innerHTML = "";

    results.forEach((result, index) => {
      const card = document.createElement("div");
      card.className = "result-card";
      card.style.animationDelay = `${index * 80}ms`;

      const stepsHtml = result.steps
        .map((step, i) => `<li><span class="step-num">${i + 1}</span>${escapeHtml(step)}</li>`)
        .join("");

      const refsHtml = result.references
        .map((ref) => `<li>${linkify(escapeHtml(ref))}</li>`)
        .join("");

      card.innerHTML = `
        <div class="card-header">
          <span class="category-tag">${escapeHtml(result.category)}</span>
          <span class="relevance-badge" title="Relevance score">${result.relevance_score}pts</span>
        </div>
        <h3 class="card-title">${escapeHtml(result.title)}</h3>
        <p class="card-summary">${escapeHtml(result.summary)}</p>
        <div class="card-steps">
          <h4>Recommended Steps</h4>
          <ol>${stepsHtml}</ol>
        </div>
        <div class="card-references">
          <h4>Legal References</h4>
          <ul>${refsHtml}</ul>
        </div>
      `;

      this.elements.resultsContainer.appendChild(card);
    });

    this.elements.resultCount.textContent = `${results.length} result${results.length !== 1 ? "s" : ""} found`;
    this.elements.resultsSection.classList.remove("hidden");
    this.setStatus(`Found ${results.length} relevant legal guidance topic(s).`, "success");

    // Smooth scroll to results
    this.elements.resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  private setStatus(message: string, type: "info" | "success" | "warning" | "error"): void {
    this.elements.statusBar.textContent = message;
    this.elements.statusBar.dataset.type = type;
  }
}

// ---- Utility Functions ----

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 3);
}

function computeRelevance(queryWords: string[], topic: any): number {
  let score = 0;
  for (const word of queryWords) {
    if (topic.keywords?.some((k: string) => k.toLowerCase().includes(word))) score += 10;
    if (topic.category?.toLowerCase().includes(word)) score += 5;
    if (topic.title?.toLowerCase().includes(word)) score += 5;
    if (topic.summary?.toLowerCase().includes(word)) score += 2;
  }
  return score;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function linkify(str: string): string {
  return str.replace(
    /(https?:\/\/[^\s<]+)/g,
    '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
  );
}

// ---- Bootstrap ----
document.addEventListener("DOMContentLoaded", () => {
  new PocketCourt();
});
