# ⚖ Pocket Court — Offline-First Legal Navigator

A clean, modular legal guidance application with a Rust core engine and a TypeScript/HTML frontend. Works fully offline using local JSON law databases, with optional online mode connecting to a REST API backend.

---

## Project Structure

```
pocket-court/
├── backend/              # Rust core engine (REST API)
│   ├── Cargo.toml
│   └── src/
│       ├── main.rs       # Entry point — server bootstrap
│       ├── error.rs      # Typed error handling
│       ├── models.rs     # Data structures (serde)
│       ├── loader.rs     # JSON data file loader
│       ├── engine.rs     # Core reasoning/search engine
│       └── api.rs        # Actix-web route handlers
├── frontend/             # TypeScript UI
│   ├── index.html        # Single-page app (self-contained)
│   ├── tsconfig.json
│   └── src/
│       └── main.ts       # Full TypeScript source
├── data/                 # Local law databases (JSON)
│   ├── us.json           # United States
│   ├── gb.json           # United Kingdom
│   └── in.json           # India
└── README.md
```

---

## Architecture

### Backend (Rust)

| Module      | Responsibility                                      |
|-------------|-----------------------------------------------------|
| `main.rs`   | Bootstraps Actix-web server, wires dependencies     |
| `error.rs`  | `AppError` enum with `thiserror`, impl `ResponseError` |
| `models.rs` | `CountryLaw`, `LegalTopic`, `SearchResult`, `SearchQuery` |
| `loader.rs` | Reads `data/*.json`, deserializes into `HashMap`    |
| `engine.rs` | Keyword tokenization + relevance scoring algorithm  |
| `api.rs`    | `GET /health`, `GET /api/countries`, `POST /api/search` |

### Frontend (TypeScript + HTML)

- **Offline mode**: Fetches `../data/<code>.json` directly in the browser. No server required.
- **Online mode**: Sends `POST /api/search` to the Rust backend at `localhost:8080`.
- Mode toggle switches seamlessly; falls back to offline if backend is unreachable.
- The `index.html` includes an inline-compiled JS block — **no build step required** to open in a browser.

### Relevance Scoring

The engine tokenizes the user's free-text situation into 3+ character words, then scores each legal topic:

| Match location   | Points |
|-----------------|--------|
| Keyword match    | +10    |
| Category match   | +5     |
| Title match      | +5     |
| Summary match    | +2     |

Results are sorted by score descending. Topics with score 0 are excluded.

---

## Setup & Running

### Prerequisites

- [Rust](https://rustup.rs/) (1.75+)
- A modern web browser (Chrome, Firefox, Safari)
- `npm` — optional, only needed to compile TypeScript; the HTML works as-is

---

### 1. Run the Frontend (Offline — No Build Required)

Simply open the frontend in a browser. Use a local file server to allow `fetch()` for JSON files:

```bash
# Python (built-in)
cd pocket-court
python3 -m http.server 3000
# Then open: http://localhost:3000/frontend/index.html
```

Or with Node.js `npx serve`:

```bash
npx serve pocket-court -p 3000
# Then open: http://localhost:3000/frontend/index.html
```

The app loads `data/*.json` automatically in **Offline mode**. No backend needed.

---

### 2. Run the Backend (Online Mode)

```bash
cd pocket-court/backend
DATA_DIR=../data cargo run --release
```

The server starts at `http://127.0.0.1:8080`.

**Available endpoints:**

| Method | Path              | Description                    |
|--------|-------------------|--------------------------------|
| GET    | `/health`         | Health check                   |
| GET    | `/api/countries`  | List all available countries   |
| POST   | `/api/search`     | Search legal topics            |

**Example search request:**

```bash
curl -X POST http://127.0.0.1:8080/api/search \
  -H "Content-Type: application/json" \
  -d '{"country_code": "US", "situation": "my landlord locked me out"}'
```

---

### 3. Compile TypeScript (Optional)

The `index.html` contains an inline-compiled JS bundle — no build step is required. If you modify `src/main.ts`:

```bash
cd pocket-court/frontend
npm install -g typescript   # one-time
tsc
# Output: dist/main.js
```

Then replace the inline `<script>` in `index.html` with:

```html
<script src="dist/main.js" type="module"></script>
```

---

## Adding a New Country

1. Create `data/<country_code_lowercase>.json` following this schema:

```json
{
  "country_code": "AU",
  "country_name": "Australia",
  "jurisdiction_note": "Federal and state laws apply...",
  "topics": [
    {
      "id": "au-tenant-001",
      "category": "Tenant Rights",
      "title": "Topic title",
      "summary": "One-paragraph summary.",
      "keywords": ["relevant", "search", "keywords"],
      "steps": ["Step 1", "Step 2", "Step 3"],
      "references": ["Relevant Act or URL"]
    }
  ]
}
```

2. Restart the backend. The loader discovers all `.json` files automatically.
3. The frontend will display the new country in the dropdown on next load (offline) or API call (online).

---

## Design Principles

- **Offline-first**: Core functionality works with zero network access.
- **Modular**: Each Rust module has a single responsibility. Frontend logic is self-contained.
- **No unnecessary dependencies**: Rust uses only `actix-web`, `serde`, `thiserror`, `log`. Frontend has zero runtime dependencies.
- **Typed errors**: All Rust error paths use `Result<T, AppError>` — no `.unwrap()` in production paths.
- **Extensible**: Add countries by dropping JSON files. Add legal topics by extending existing JSON.

---

## Legal Disclaimer

Pocket Court provides **general legal information for educational purposes only**. It is not a substitute for advice from a qualified attorney licensed in your jurisdiction. Always consult a licensed legal professional for advice specific to your situation.

---

## License

MIT
