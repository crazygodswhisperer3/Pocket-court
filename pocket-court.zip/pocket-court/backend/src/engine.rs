use std::collections::HashMap;
use crate::error::AppError;
use crate::models::{CountryLaw, CountryInfo, SearchResult};
use crate::loader::load_all_countries;

/// The core legal reasoning engine.
/// Holds all loaded country data in memory for fast offline querying.
pub struct LegalEngine {
    countries: HashMap<String, CountryLaw>,
}

impl LegalEngine {
    /// Initializes the engine by loading all country data from `data_dir`.
    pub fn new(data_dir: &str) -> Result<Self, AppError> {
        let countries = load_all_countries(data_dir)?;
        Ok(Self { countries })
    }

    /// Returns a list of all available countries.
    pub fn list_countries(&self) -> Vec<CountryInfo> {
        let mut list: Vec<CountryInfo> = self.countries.values().map(|c| CountryInfo {
            code: c.country_code.clone(),
            name: c.country_name.clone(),
        }).collect();
        list.sort_by(|a, b| a.name.cmp(&b.name));
        list
    }

    /// Searches topics for a given country using keyword matching.
    /// Returns results sorted by relevance score (descending).
    pub fn search(
        &self,
        country_code: &str,
        situation: &str,
    ) -> Result<Vec<SearchResult>, AppError> {
        let code = country_code.to_lowercase();
        let country = self.countries.get(&code)
            .ok_or_else(|| AppError::CountryNotFound(country_code.to_string()))?;

        let query_words = tokenize(situation);
        if query_words.is_empty() {
            return Err(AppError::NoResults(situation.to_string()));
        }

        let mut results: Vec<SearchResult> = country.topics.iter()
            .filter_map(|topic| {
                let score = compute_relevance(&query_words, topic);
                if score > 0 {
                    Some(SearchResult {
                        topic_id: topic.id.clone(),
                        category: topic.category.clone(),
                        title: topic.title.clone(),
                        summary: topic.summary.clone(),
                        steps: topic.steps.clone(),
                        references: topic.references.clone(),
                        relevance_score: score,
                    })
                } else {
                    None
                }
            })
            .collect();

        // Sort by relevance descending
        results.sort_by(|a, b| b.relevance_score.cmp(&a.relevance_score));

        if results.is_empty() {
            return Err(AppError::NoResults(situation.to_string()));
        }

        Ok(results)
    }
}

/// Tokenizes a query string into lowercase words, filtering short tokens.
fn tokenize(text: &str) -> Vec<String> {
    text.to_lowercase()
        .split(|c: char| !c.is_alphanumeric())
        .filter(|w| w.len() >= 3)
        .map(|w| w.to_string())
        .collect()
}

/// Computes a relevance score between query tokens and a legal topic.
/// Higher weight for keyword matches vs. title/summary matches.
fn compute_relevance(query_words: &[String], topic: &crate::models::LegalTopic) -> u32 {
    let mut score: u32 = 0;

    for word in query_words {
        // Keyword match: high weight
        if topic.keywords.iter().any(|k| k.to_lowercase().contains(word.as_str())) {
            score += 10;
        }
        // Category match: medium weight
        if topic.category.to_lowercase().contains(word.as_str()) {
            score += 5;
        }
        // Title match: medium weight
        if topic.title.to_lowercase().contains(word.as_str()) {
            score += 5;
        }
        // Summary match: low weight
        if topic.summary.to_lowercase().contains(word.as_str()) {
            score += 2;
        }
    }

    score
}
