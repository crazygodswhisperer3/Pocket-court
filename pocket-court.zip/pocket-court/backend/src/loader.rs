use std::collections::HashMap;
use std::path::Path;
use crate::error::AppError;
use crate::models::CountryLaw;

/// Loads all country law JSON files from the given directory.
/// Each file must be named `<country_code>.json` (e.g., `us.json`).
pub fn load_all_countries(data_dir: &str) -> Result<HashMap<String, CountryLaw>, AppError> {
    let dir = Path::new(data_dir);
    if !dir.exists() {
        return Err(AppError::DataDir(format!("Directory not found: {}", data_dir)));
    }

    let mut map = HashMap::new();

    for entry in std::fs::read_dir(dir).map_err(AppError::Io)? {
        let entry = entry.map_err(AppError::Io)?;
        let path = entry.path();

        // Only process .json files
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }

        let content = std::fs::read_to_string(&path).map_err(AppError::Io)?;
        let law: CountryLaw = serde_json::from_str(&content).map_err(AppError::Json)?;
        let code = law.country_code.to_lowercase();

        log::info!("Loaded country data: {} ({})", law.country_name, code);
        map.insert(code, law);
    }

    log::info!("Total countries loaded: {}", map.len());
    Ok(map)
}
