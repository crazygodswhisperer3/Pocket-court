use serde::{Deserialize, Serialize};

/// A single legal topic with associated keywords and guidance.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LegalTopic {
    pub id: String,
    pub category: String,
    pub title: String,
    pub summary: String,
    pub keywords: Vec<String>,
    pub steps: Vec<String>,
    pub references: Vec<String>,
}

/// Country law database loaded from a JSON file.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CountryLaw {
    pub country_code: String,
    pub country_name: String,
    pub jurisdiction_note: String,
    pub topics: Vec<LegalTopic>,
}

/// A search result returned to the frontend.
#[derive(Debug, Serialize, Deserialize)]
pub struct SearchResult {
    pub topic_id: String,
    pub category: String,
    pub title: String,
    pub summary: String,
    pub steps: Vec<String>,
    pub references: Vec<String>,
    pub relevance_score: u32,
}

/// Incoming query from the frontend.
#[derive(Debug, Deserialize)]
pub struct SearchQuery {
    pub country_code: String,
    pub situation: String,
}

/// List of available countries returned by the API.
#[derive(Debug, Serialize)]
pub struct CountryInfo {
    pub code: String,
    pub name: String,
}

/// API response wrapper.
#[derive(Debug, Serialize)]
pub struct ApiResponse<T: Serialize> {
    pub success: bool,
    pub data: T,
    pub count: usize,
}
