use thiserror::Error;

/// Application-level errors for Pocket Court.
#[derive(Debug, Error)]
pub enum AppError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("JSON parse error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("Country not found: {0}")]
    CountryNotFound(String),

    #[error("No results found for query: {0}")]
    NoResults(String),

    #[error("Data directory error: {0}")]
    DataDir(String),
}

impl actix_web::ResponseError for AppError {
    fn status_code(&self) -> actix_web::http::StatusCode {
        match self {
            AppError::CountryNotFound(_) => actix_web::http::StatusCode::NOT_FOUND,
            AppError::NoResults(_) => actix_web::http::StatusCode::OK,
            _ => actix_web::http::StatusCode::INTERNAL_SERVER_ERROR,
        }
    }

    fn error_response(&self) -> actix_web::HttpResponse {
        use actix_web::HttpResponse;
        use serde_json::json;
        HttpResponse::build(self.status_code()).json(json!({
            "error": self.to_string()
        }))
    }
}
