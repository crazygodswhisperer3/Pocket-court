use actix_web::{web, get, post, HttpResponse, Responder};
use std::sync::Arc;
use crate::engine::LegalEngine;
use crate::models::{SearchQuery, ApiResponse};
use crate::error::AppError;

/// Configure all API routes.
pub fn configure_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(health)
       .service(list_countries)
       .service(search_legal);
}

/// Health check endpoint.
#[get("/health")]
async fn health() -> impl Responder {
    HttpResponse::Ok().json(serde_json::json!({ "status": "ok", "service": "pocket-court" }))
}

/// Returns all available countries.
#[get("/api/countries")]
async fn list_countries(engine: web::Data<Arc<LegalEngine>>) -> Result<HttpResponse, AppError> {
    let countries = engine.list_countries();
    let count = countries.len();
    Ok(HttpResponse::Ok().json(ApiResponse {
        success: true,
        count,
        data: countries,
    }))
}

/// Searches legal topics for a given country and situation.
#[post("/api/search")]
async fn search_legal(
    engine: web::Data<Arc<LegalEngine>>,
    query: web::Json<SearchQuery>,
) -> Result<HttpResponse, AppError> {
    let results = engine.search(&query.country_code, &query.situation)?;
    let count = results.len();
    Ok(HttpResponse::Ok().json(ApiResponse {
        success: true,
        count,
        data: results,
    }))
}
