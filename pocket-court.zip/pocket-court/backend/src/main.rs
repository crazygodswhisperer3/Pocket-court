mod error;
mod models;
mod engine;
mod api;
mod loader;

use actix_web::{web, App, HttpServer, middleware};
use actix_cors::Cors;
use std::sync::Arc;
use engine::LegalEngine;

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    env_logger::init_from_env(env_logger::Env::default().default_filter_or("info"));

    let data_dir = std::env::var("DATA_DIR")
        .unwrap_or_else(|_| "../data".to_string());

    let engine = Arc::new(
        LegalEngine::new(&data_dir).expect("Failed to initialize legal engine")
    );

    log::info!("Pocket Court engine ready. Starting server on http://127.0.0.1:8080");

    HttpServer::new(move || {
        let cors = Cors::default()
            .allow_any_origin()
            .allow_any_method()
            .allow_any_header();

        App::new()
            .wrap(cors)
            .wrap(middleware::Logger::default())
            .app_data(web::Data::new(engine.clone()))
            .configure(api::configure_routes)
    })
    .bind("127.0.0.1:8080")?
    .run()
    .await
}
